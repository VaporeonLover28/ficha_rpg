var name = document.querySelector("#nome")
var level = document.querySelector("#nivel")
var strenght = document.querySelector("#forca")
var dexterity = document.querySelector("#agilidade")
var armor = document.querySelector("#armadura")

let novonome
let label = ""

nome.addEventListener("change",lerNome)
nivel.addEventListener("change",addPrefixo)

function addPrefixo() {
    if(nivel.value < 0)
    {
        label = "[HACKER] "
    }
    else if(nivel.value > 0 && nivel.value <= 5)
    {
        label = "[NOOBASSO] "
    }
    else if(nivel.value > 5 && nivel.value <= 10)
    {
        label = "[DECENTE] "
    }
    else if(nivel.value > 10)
    {
        label = "[SEM VIDA] "
    }
    nome.value = label + novonome
}

function lerNome() {
    novonome = nome.value
}
